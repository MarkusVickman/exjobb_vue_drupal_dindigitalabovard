<?php

namespace Drupal\symfony_mailer\Exception;

/**
 * Exception to cancel email sending.
 */
class SkipMailException extends \Exception {

}
