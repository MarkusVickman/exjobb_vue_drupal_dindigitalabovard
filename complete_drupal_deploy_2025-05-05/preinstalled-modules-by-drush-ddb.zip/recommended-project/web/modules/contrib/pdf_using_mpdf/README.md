Introduction
------------
* Use this module to convert HTML to PDF using the mPDF PHP Library
* Use this module to create editable PDF files


Requirements
------------
* If the mPDF library is not installed automatically:
  Use below `composer` command to install the library from the directory where your `composer.json` is!
 ```
  composer require 'mpdf/mpdf:^8.2'
 ```

Configuration
-------------
* Go to this URL and set your PDF preferences : **/admin/config/user-interface/mpdf**
* Set permissions for which roles can generate a PDF document : **/admin/people/permissions**


Usage
-----
* This module provides PDF generation for nodes out-of-the-box >> `full` view mode, by default.
* After permissions have been set for node types, use `Generate PDF` URL on node view to generate a valid PDF
* For any other entity, or an HTML, refer below the developer guide.


For Developers
--------------
* Use a custom Drupal service `pdf_using_mpdf.conversion` for PDF generation
* This service primarily needs HTML output.
* To generate a PDF programmatically from anywhere in your project, use the following:

 ```php
   /** @var \Drupal\pdf_using_mpdf\ConvertToPdfInterface $pdf */
   $pdfService = \Drupal::service('pdf_using_mpdf.conversion');
   $pdfService->convert($html, $settings, $context);
 ```
    Parameters used above :
    -----------------------
    $html                 > Rendered HTML of an entity or HTML tags in string format.
    $settings (optional)  > Use this parameter to overwrite settings from the configuration page.
    $context  (optional)  > Useful to replace tokens set in the mPDF configuration.

* For even better control, checkout `pdf_using_mpdf.api.php` file to look at the hooks provided by this module.
* With these hooks, you can use a separate set of mPDF settings for every use case.
