<?php

namespace Drupal\Tests\pdf_using_mpdf\Unit\Conversion;

use Drupal\Tests\UnitTestCase;

/**
 * Base tests class.
 *
 * @package Drupal\Tests\pdf_using_mpdf\Unit\Conversion
 */
class ConvertToPdfTest extends UnitTestCase {

}
