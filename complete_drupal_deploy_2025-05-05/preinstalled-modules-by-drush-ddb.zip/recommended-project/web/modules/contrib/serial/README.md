# Serial Field
Drupal 8 port of the [Serial Field module]
(https://www.drupal.org/project/serial).
[Related issue](https://www.drupal.org/node/2767507) on Drupal.org.

The [Drupal Module Upgrader]
(https://www.drupal.org/project/drupalmoduleupgrader)
has been executed against the 7.x-1.x-dev release.

Using the [issue tracker](https://github.com/r-daneelolivaw/serial/issues) 
as a roadmap for the port.
