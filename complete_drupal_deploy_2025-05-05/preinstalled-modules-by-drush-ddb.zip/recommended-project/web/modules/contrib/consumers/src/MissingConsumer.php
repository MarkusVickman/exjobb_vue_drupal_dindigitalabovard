<?php

namespace Drupal\consumers;

/**
 * Exception thrown when a consumer is missing.
 */
class MissingConsumer extends \Exception {}
